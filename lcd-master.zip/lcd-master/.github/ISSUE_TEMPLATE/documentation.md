---
name: Documentation
about: Issues specifically related to typos or missing information in the Wiki or
  other documentation file
title: ''
labels: documentation
assignees: ''

---

**Describe the issue**
Add a clear and concise description of the issue here.

**Document**
- File: `add the filename here`
